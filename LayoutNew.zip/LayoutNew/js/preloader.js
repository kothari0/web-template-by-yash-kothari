(function ($) {
  "use strict";
  //Preloader
  window.addEventListener( 'load', function () {
        var preloadpage = document.getElementById( "page_loader" );
        preloadpage.style.display = "none";
  });
})(jQuery);